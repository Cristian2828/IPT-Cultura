<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Ryan extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('db','ryan');
    }
   	
   	function index(){

   		$data['tbl_data'] = $this->ryan->getdata();
   		$this->load->view('sample/index' ,$data);
   	}
}


?>