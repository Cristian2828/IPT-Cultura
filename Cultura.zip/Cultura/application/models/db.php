<?php  
defined('BASEPATH') OR exit('No direct script access allowed');


	/**
	 * summary
	 */
	class Db extends CI_Model
	{
	    /**
	     * summary
	     */
	    public function getdata()
	    {
	    	$table = $this->db->table_exists('cultura');
	    	if ($table) {
	    		$query = $this->db->get('cultura');
	    		if ($query->num_rows() > 0) {
	    			return $query->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
	    }
	}


?>