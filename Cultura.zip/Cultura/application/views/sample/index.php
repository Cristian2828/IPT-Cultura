<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
	<link href="https://fonts.googleapis.com/
	css2?family=Acme&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Fira+Sans&display=swap" rel="stylesheet">
</head>
<body>


<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('ryan/index'); ?>"><span>Personal Information</span></a>
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>
				<li><a href="#">Home</a></li>
			</ul>
		</div>
	</header>
<!-- end of header -->


<!-- personal -->

	<div class="box">
		<div class="box_content">
			<div class="img_per">
				<img src="<?php echo base_url();?>assets/images/ryan.jpg" alt="Images" width="400" height="380">
			</div>
			<ul>
				<li><img src="<?php echo base_url()?>assets/svg/user-circle-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/envelope-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->email;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/home-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->address;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/male-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->Gender;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/user-circle-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->citizenship;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/user-circle-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->age;
							}
						}
					 ?>
				</span></li>
				<li><img src="<?php echo base_url()?>assets/svg/birthday-cake-solid.svg" alt="User" width="40" height="40"><span>
					<?php 
						if ($tbl_data) {
							foreach ($tbl_data as $data) {
							    echo $data->birthday;
							}
						}
					 ?>
				</span></li>
			</ul>
		</div>
	</div>


<!-- end of personal -->


	



	
</body>
</html>
